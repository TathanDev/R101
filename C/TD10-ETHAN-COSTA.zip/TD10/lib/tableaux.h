#pragma once

int* tableauScanfTaille(int taille);

void afficherTab(int* tab, int taille);